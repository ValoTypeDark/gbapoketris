#include "pokemon_database.h"

// Pokemon database - Complete data matching Python version
// Format: {dex_num, "name", modes, r, n, s, h, m, un, viv, alc, special, "sprite", "type1", "type2", "height", "weight", "dex_text"}
// Where: r=rookie, n=normal, s=super, h=hyper, m=master, un=unown, viv=vivillon, alc=alcremie
const PokemonData POKEMON_DATABASE[TOTAL_POKEMON] = {
    // Gen 1 Starters
    {1, "Bulbasaur", MODE_ROOKIE | MODE_HYPER | MODE_MASTER, 
     16, 0, 0, 7, 7, 0, 0, 0, 0, "0001.png", "Grass", "Poison",
     "0.7 m", "6.9 kg", "A strange seed was planted on its back at birth. The plant sprouts and grows with this Pokemon."},
    
    {4, "Charmander", MODE_ROOKIE | MODE_HYPER | MODE_MASTER,
     16, 0, 0, 7, 7, 0, 0, 0, 0, 0, "0004.png", "Fire", NULL,
     "0.6 m", "8.5 kg", "Obviously prefers hot places. When it rains, steam is said to spout from the tip of its tail."},
    
    {7, "Squirtle", MODE_ROOKIE | MODE_HYPER | MODE_MASTER,
     16, 0, 0, 7, 7, 0, 0, 0, 0, 0, "0007.png", "Water", NULL,
     "0.5 m", "9.0 kg", "After birth, its back swells and hardens into a shell. Powerfully sprays foam from its mouth."},
    
    // Gen 1 Common
    {16, "Pidgey", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0016.png", "Normal", "Flying",
     "0.3 m", "1.8 kg", "A common sight in forests and woods. It flaps its wings at ground level to kick up blinding sand."},
    
    {19, "Rattata", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0019.png", "Normal", NULL,
     "0.3 m", "3.5 kg", "Bites anything when it attacks. Small and very quick, it is a common sight in many places."},
    
    {25, "Pikachu", MODE_ALL,
     11, 11, 11, 11, 11, 0, 0, 0, 0, 0, "0025.png", "Electric", NULL,
     "0.4 m", "6.0 kg", "When several of these Pokemon gather, their electricity could build and cause lightning storms."},
    
    {43, "Oddish", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0043.png", "Grass", "Poison",
     "0.5 m", "5.4 kg", "During the day, it keeps its face buried in the ground. At night, it wanders around sowing its seeds."},
    
    {63, "Abra", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 16, 16, 0, 0, 0, 0, 0, 0, 0, "0063.png", "Psychic", NULL,
     "0.9 m", "19.5 kg", "Using its ability to read minds, it will identify impending danger and teleport to safety."},
    
    {92, "Gastly", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0092.png", "Ghost", "Poison",
     "1.3 m", "0.1 kg", "Almost invisible, this gaseous Pokemon cloaks the target and puts it to sleep without notice."},
    
    {133, "Eevee", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER | MODE_HYPER,
     11, 11, 11, 11, 0, 0, 0, 0, 0, 0, "0133.png", "Normal", NULL,
     "0.3 m", "6.5 kg", "Its genetic code is irregular. It may mutate if it is exposed to radiation from element stones."},
    
    {143, "Snorlax", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER | MODE_HYPER,
     11, 11, 11, 11, 0, 0, 0, 0, 0, 0, "0143.png", "Normal", NULL,
     "2.1 m", "460.0 kg", "Very lazy. Just eats and sleeps. As its rotund bulk builds, it becomes steadily more slothful."},
    
    // Gen 1 Evolutions
    {3, "Venusaur", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0003.png", "Grass", "Poison",
     "2.0 m", "100.0 kg", "The plant blooms when it is absorbing solar energy. It stays on the move to seek sunlight."},
    
    {6, "Charizard", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0006.png", "Fire", "Flying",
     "1.7 m", "90.5 kg", "Spits fire that is hot enough to melt boulders. Known to cause forest fires unintentionally."},
    
    {9, "Blastoise", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0009.png", "Water", NULL,
     "1.6 m", "85.5 kg", "A brutal Pokemon with pressurized water jets on its shell. They are used for high speed tackles."},
    
    {18, "Pidgeot", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0018.png", "Normal", "Flying",
     "1.5 m", "39.5 kg", "When hunting, it skims the surface of water at high speed to pick off unwary prey such as Magikarp."},
    
    {94, "Gengar", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0094.png", "Ghost", "Poison",
     "1.5 m", "40.5 kg", "Under a full moon, this Pokemon likes to mimic the shadows of people and laugh at their fright."},
    
    {130, "Gyarados", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0130.png", "Water", "Flying",
     "6.5 m", "235.0 kg", "Rarely seen in the wild. Huge and vicious, it is capable of destroying entire cities in a rage."},
    
    {131, "Lapras", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0131.png", "Water", "Ice",
     "2.5 m", "220.0 kg", "A Pokemon that has been overhunted almost to extinction. It can ferry people across the water."},
    
    {149, "Dragonite", MODE_HYPER | MODE_MASTER,
     0, 0, 0, 7, 7, 0, 0, 0, 0, 0, "0149.png", "Dragon", "Flying",
     "2.2 m", "210.0 kg", "An extremely rarely seen marine Pokemon. Its intelligence is said to match that of humans."},
    
    // Gen 1 Legendaries
    {144, "Articuno", MODE_HYPER | MODE_MASTER,
     0, 0, 0, 7, 7, 1, 0, 0, 0, 0, "0144.png", "Ice", "Flying",
     "1.7 m", "55.4 kg", "A legendary bird Pokemon that is said to appear to doomed people who are lost in icy mountains."},
    
    {145, "Zapdos", MODE_HYPER | MODE_MASTER,
     0, 0, 0, 7, 7, 1, 0, 0, 0, 0, "0145.png", "Electric", "Flying",
     "1.6 m", "52.6 kg", "A legendary bird Pokemon that is said to appear from clouds while dropping enormous lightning bolts."},
    
    {146, "Moltres", MODE_HYPER | MODE_MASTER,
     0, 0, 0, 7, 7, 1, 0, 0, 0, 0, "0146.png", "Fire", "Flying",
     "2.0 m", "60.0 kg", "Known as the legendary bird of fire. Every flap of its wings creates a dazzling flash of flames."},
    
    {150, "Mewtwo", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0150.png", "Psychic", NULL,
     "2.0 m", "122.0 kg", "It was created by a scientist after years of horrific gene splicing and DNA engineering experiments."},
    
    {151, "Mew", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0151.png", "Psychic", NULL,
     "0.4 m", "4.0 kg", "So rare that it is still said to be a mirage by many experts. Only a few people have seen it worldwide."},
    
    // Gen 2
    {152, "Chikorita", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0152.png", "Grass", NULL,
     "0.9 m", "6.4 kg", "A sweet aroma gently wafts from the leaf on its head. It is docile and loves to soak up sun rays."},
    
    {155, "Cyndaquil", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0155.png", "Fire", NULL,
     "0.5 m", "7.9 kg", "It is timid, and always curls itself up in a ball. If attacked, it flares up its back for protection."},
    
    {158, "Totodile", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0158.png", "Water", NULL,
     "0.6 m", "9.5 kg", "Its well-developed jaws are powerful and capable of crushing anything. Even its trainer must be careful."},
    
    {172, "Pichu", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0172.png", "Electric", NULL,
     "0.3 m", "2.0 kg", "It is not yet skilled at storing electricity. It may send out a jolt if amused or startled."},
    
    {175, "Togepi", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0175.png", "Fairy", NULL,
     "0.3 m", "1.5 kg", "The shell seems to be filled with joy. It is said that it will share good luck when treated kindly."},
    
    {196, "Espeon", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0196.png", "Psychic", NULL,
     "0.9 m", "26.5 kg", "It uses the fine hair that covers its body to sense air currents and predict its enemy's actions."},
    
    {197, "Umbreon", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0197.png", "Dark", NULL,
     "1.0 m", "27.0 kg", "When agitated, this Pokemon protects itself by spraying poisonous sweat from its pores."},
    
    {249, "Lugia", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0249.png", "Psychic", "Flying",
     "5.2 m", "216.0 kg", "It is said to be the guardian of the seas. It is rumored to have been seen on the night of a storm."},
    
    {250, "Ho-Oh", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0250.png", "Fire", "Flying",
     "3.8 m", "199.0 kg", "Legends claim this Pokemon flies the world's skies continuously on its magnificent seven-colored wings."},
    
    // Gen 3
    {252, "Treecko", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0252.png", "Grass", NULL,
     "0.5 m", "5.0 kg", "The soles of its feet have tiny spikes that enable it to walk on walls and ceilings."},
    
    {255, "Torchic", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0255.png", "Fire", NULL,
     "0.4 m", "2.5 kg", "A fire burns inside, so it feels very warm to hug. It launches fireballs of 1,800 degrees F."},
    
    {258, "Mudkip", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0258.png", "Water", NULL,
     "0.4 m", "7.6 kg", "The fin on Mudkip's head acts as highly sensitive radar. Using this fin to sense movements of water and air."},
    
    {282, "Gardevoir", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0282.png", "Psychic", "Fairy",
     "1.6 m", "48.4 kg", "It has the power to predict the future. Its power peaks when it is protecting its Trainer."},
    
    {359, "Absol", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0359.png", "Dark", NULL,
     "1.2 m", "47.0 kg", "Every time Absol appears before people, it is followed by a disaster such as an earthquake or a tidal wave."},
    
    {384, "Rayquaza", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0384.png", "Dragon", "Flying",
     "7.0 m", "206.5 kg", "It lives in the ozone layer far above the clouds and cannot be seen from the ground."},
    
    // Gen 4+
    {393, "Piplup", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0393.png", "Water", NULL,
     "0.4 m", "5.2 kg", "It lives along shores in northern countries. A skilled swimmer, it dives for over 10 minutes to hunt."},
    
    {447, "Riolu", MODE_NORMAL | MODE_SUPER | MODE_HYPER,
     0, 11, 11, 11, 0, 0, 0, 0, 0, 0, "0447.png", "Fighting", NULL,
     "0.7 m", "20.2 kg", "The aura that emanates from its body intensifies to alert others if it is afraid or sad."},
    
    {448, "Lucario", MODE_SUPER | MODE_HYPER | MODE_MASTER,
     0, 0, 7, 7, 7, 0, 0, 0, 0, 0, "0448.png", "Fighting", "Steel",
     "1.2 m", "54.0 kg", "It has the ability to sense the auras of all things. It understands human speech."},
    
    {483, "Dialga", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0483.png", "Steel", "Dragon",
     "5.4 m", "683.0 kg", "It has the power to control time. It appears in Sinnoh-region myths as an ancient deity."},
    
    {484, "Palkia", MODE_MASTER,
     0, 0, 0, 0, 7, 1, 0, 0, 0, 0, "0484.png", "Water", "Dragon",
     "4.2 m", "336.0 kg", "It has the ability to distort space. It is described as a deity in Sinnoh-region mythology."},
    
    {650, "Chespin", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0650.png", "Grass", NULL,
     "0.4 m", "9.0 kg", "The quills on its head are usually soft. When it flexes them, the points become so hard and sharp."},
    
    {653, "Fennekin", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0653.png", "Fire", NULL,
     "0.4 m", "9.4 kg", "Eating a twig fills it with energy, and its roomy ears give vent to air hotter than 390 degrees F."},
    
    {656, "Froakie", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0656.png", "Water", NULL,
     "0.3 m", "7.0 kg", "It secretes flexible bubbles from its chest and back. The bubbles reduce the damage it would take."},
    
    {722, "Rowlet", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0722.png", "Grass", "Flying",
     "0.3 m", "1.5 kg", "This wary Pokemon uses photosynthesis to store up energy during the day, while becoming active at night."},
    
    {725, "Litten", MODE_ROOKIE | MODE_NORMAL | MODE_SUPER,
     11, 11, 11, 0, 0, 0, 0, 0, 0, 0, "0725.png", "Fire", NULL,
     "0.4 m", "4.3 kg", "While grooming itself, it builds up fur inside its stomach. It sets the fur alight and spews fiery attacks."}
};

// Helper function
const PokemonData* get_pokemon_data(int index) {
    if(index >= 0 && index < TOTAL_POKEMON) {
        return &POKEMON_DATABASE[index];
    }
    return &POKEMON_DATABASE[0];
}

// Get turn count for specific mode
u8 get_pokemon_turns(int index, u8 mode) {
    const PokemonData* pdata = get_pokemon_data(index);
    switch(mode) {
        case 0: return pdata->turns_rookie;   // MODE_ROOKIE
        case 1: return pdata->turns_normal;   // MODE_NORMAL
        case 2: return pdata->turns_super;    // MODE_SUPER
        case 3: return pdata->turns_hyper;    // MODE_HYPER
        case 4: return pdata->turns_master;   // MODE_MASTER
        case 5: return pdata->turns_unown;    // MODE_UNOWN (Bonus)
        case 6: return pdata->turns_vivillon; // MODE_VIVILLON (Bonus)
        case 7: return pdata->turns_alcremie; // MODE_ALCREMIE (Bonus)
        default: return 11;  // Fallback
    }
}
