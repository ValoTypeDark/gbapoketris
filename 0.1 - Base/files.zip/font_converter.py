#!/usr/bin/env python3
"""
Font to GBA Bitmap Converter
Converts TrueType/OpenType fonts to C bitmap data for GBA
"""

from PIL import Image, ImageDraw, ImageFont
import sys
import os

def generate_font_bitmap(font_path, font_size, output_name, chars=None):
    """
    Generate bitmap font data from a TrueType font
    
    Args:
        font_path: Path to .ttf or .otf font file
        font_size: Size in pixels
        output_name: Name for the output C file
        chars: String of characters to include (default: printable ASCII)
    """
    
    if chars is None:
        # Default: space through Z (32-90)
        chars = ''.join(chr(i) for i in range(32, 91))
    
    try:
        font = ImageFont.truetype(font_path, font_size)
    except Exception as e:
        print(f"Error loading font: {e}")
        return False
    
    # Determine character dimensions
    # We'll use a fixed width for simplicity
    max_width = 0
    max_height = 0
    
    char_data = {}
    
    for char in chars:
        # Create a temporary image to measure this character
        temp_img = Image.new('1', (32, 32), 0)
        draw = ImageDraw.Draw(temp_img)
        
        # Draw character
        draw.text((0, 0), char, font=font, fill=1)
        
        # Get bounding box
        bbox = temp_img.getbbox()
        if bbox:
            width = bbox[2] - bbox[0]
            height = bbox[3] - bbox[1]
            max_width = max(max_width, width)
            max_height = max(max_height, height)
            
            # Store character image data
            char_data[char] = (temp_img, bbox)
    
    print(f"Font metrics: {max_width}x{max_height} pixels")
    
    # Generate C code
    c_code = []
    c_code.append(f"// Generated font data from {os.path.basename(font_path)}")
    c_code.append(f"// Font size: {font_size}pt, Character size: {max_width}x{max_height}")
    c_code.append("")
    c_code.append("#include <gba_types.h>")
    c_code.append("")
    c_code.append(f"#define FONT_{output_name.upper()}_WIDTH {max_width}")
    c_code.append(f"#define FONT_{output_name.upper()}_HEIGHT {max_height}")
    c_code.append("")
    
    # Generate bitmap data for each character
    c_code.append(f"// Bitmap data: each character is {max_height} bytes ({max_width} bits wide)")
    c_code.append(f"const u8 font_{output_name}_data[][{max_height}] = {{")
    
    for i, char in enumerate(chars):
        if char not in char_data:
            # Character not renderable, use empty
            c_code.append(f"    // {repr(char)} (not renderable)")
            c_code.append(f"    {{{', '.join(['0x00'] * max_height)}}},")
            continue
        
        img, bbox = char_data[char]
        
        # Extract bitmap data
        bitmap_rows = []
        for y in range(max_height):
            row_value = 0
            for x in range(max_width):
                # Check if pixel is set
                px_x = bbox[0] + x if bbox else x
                px_y = bbox[1] + y if bbox else y
                
                if px_x < img.width and px_y < img.height:
                    pixel = img.getpixel((px_x, px_y))
                    if pixel:
                        row_value |= (1 << (max_width - 1 - x))
            
            bitmap_rows.append(f"0x{row_value:02X}")
        
        c_code.append(f"    // '{char}' (ASCII {ord(char)})")
        c_code.append(f"    {{{', '.join(bitmap_rows)}}},")
    
    c_code.append("};")
    c_code.append("")
    
    # Add helper function to draw character
    c_code.append(f"// Helper function to draw a character")
    c_code.append(f"void draw_char_{output_name}(int x, int y, char c, u16 color, u16* buffer, int buffer_width) {{")
    c_code.append(f"    if(c < 32 || c > 90) c = 32; // Default to space")
    c_code.append(f"    const u8* glyph = font_{output_name}_data[c - 32];")
    c_code.append(f"    ")
    c_code.append(f"    for(int row = 0; row < FONT_{output_name.upper()}_HEIGHT; row++) {{")
    c_code.append(f"        u8 row_data = glyph[row];")
    c_code.append(f"        for(int col = 0; col < FONT_{output_name.upper()}_WIDTH; col++) {{")
    c_code.append(f"            if(row_data & (1 << (FONT_{output_name.upper()}_WIDTH - 1 - col))) {{")
    c_code.append(f"                int px = x + col;")
    c_code.append(f"                int py = y + row;")
    c_code.append(f"                if(px >= 0 && px < buffer_width && py >= 0 && py < 160) {{")
    c_code.append(f"                    buffer[py * buffer_width + px] = color;")
    c_code.append(f"                }}")
    c_code.append(f"            }}")
    c_code.append(f"        }}")
    c_code.append(f"    }}")
    c_code.append(f"}}")
    
    # Write to file
    output_file = f"font_{output_name}.c"
    with open(output_file, 'w') as f:
        f.write('\n'.join(c_code))
    
    print(f"Generated: {output_file}")
    
    # Also create header file
    h_code = []
    h_code.append(f"#ifndef FONT_{output_name.upper()}_H")
    h_code.append(f"#define FONT_{output_name.upper()}_H")
    h_code.append("")
    h_code.append("#include <gba_types.h>")
    h_code.append("")
    h_code.append(f"#define FONT_{output_name.upper()}_WIDTH {max_width}")
    h_code.append(f"#define FONT_{output_name.upper()}_HEIGHT {max_height}")
    h_code.append("")
    h_code.append(f"extern const u8 font_{output_name}_data[][{max_height}];")
    h_code.append("")
    h_code.append(f"void draw_char_{output_name}(int x, int y, char c, u16 color, u16* buffer, int buffer_width);")
    h_code.append("")
    h_code.append("#endif")
    
    header_file = f"font_{output_name}.h"
    with open(header_file, 'w') as f:
        f.write('\n'.join(h_code))
    
    print(f"Generated: {header_file}")
    
    return True

def main():
    if len(sys.argv) < 4:
        print("Usage: python font_converter.py <font.ttf> <size> <output_name>")
        print("Example: python font_converter.py arial.ttf 8 arial8")
        print()
        print("Common system font locations:")
        print("  Windows: C:\\Windows\\Fonts\\")
        print("  Mac: /System/Library/Fonts/")
        print("  Linux: /usr/share/fonts/")
        sys.exit(1)
    
    font_path = sys.argv[1]
    font_size = int(sys.argv[2])
    output_name = sys.argv[3]
    
    if not os.path.exists(font_path):
        print(f"Error: Font file not found: {font_path}")
        sys.exit(1)
    
    print(f"Converting font: {font_path}")
    print(f"Size: {font_size}pt")
    print(f"Output name: {output_name}")
    print()
    
    if generate_font_bitmap(font_path, font_size, output_name):
        print()
        print("Success! To use in your GBA project:")
        print(f"1. Copy font_{output_name}.c to source/")
        print(f"2. Copy font_{output_name}.h to include/")
        print(f"3. In your code: #include \"font_{output_name}.h\"")
        print(f"4. Use: draw_char_{output_name}(x, y, 'A', color, back_buffer, 240);")

if __name__ == "__main__":
    main()
