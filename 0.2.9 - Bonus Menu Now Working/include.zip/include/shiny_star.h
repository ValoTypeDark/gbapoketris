#ifndef SHINY_STAR_H
#define SHINY_STAR_H

#include <gba.h>

// Shiny star indicator (16x16 pixels)
extern const u16 shiny_star_data[256];

#endif
