#ifndef BG_VIVILLON_H
#define BG_VIVILLON_H

#include <gba_types.h>

extern const u16 bg_vivillon_bitmap[38400];

#endif
