#ifndef BG_UNOWN_H
#define BG_UNOWN_H

#include <gba_types.h>

extern const u16 bg_unown_bitmap[38400];

#endif
