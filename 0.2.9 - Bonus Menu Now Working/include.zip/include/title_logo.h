#ifndef TITLE_LOGO_H
#define TITLE_LOGO_H

#define TITLE_LOGO_WIDTH 220
#define TITLE_LOGO_HEIGHT 132

extern const unsigned short title_logoBitmap[29040];

#endif // TITLE_LOGO_H
