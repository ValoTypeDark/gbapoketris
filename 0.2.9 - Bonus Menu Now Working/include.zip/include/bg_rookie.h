// Auto-generated from /mnt/user-data/uploads/rookie.png
#ifndef BG_ROOKIE_H
#define BG_ROOKIE_H

#include <gba.h>

#define BG_ROOKIE_WIDTH 240
#define BG_ROOKIE_HEIGHT 160

extern const u16 bg_rookie[38400];  // 240x160 pixels

#endif // BG_ROOKIE_H
