// Auto-generated from /mnt/user-data/uploads/normal.png
#ifndef BG_NORMAL_H
#define BG_NORMAL_H

#include <gba.h>

#define BG_NORMAL_WIDTH 240
#define BG_NORMAL_HEIGHT 160

extern const u16 bg_normal[38400];  // 240x160 pixels

#endif // BG_NORMAL_H
