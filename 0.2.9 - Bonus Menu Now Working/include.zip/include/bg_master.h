// Auto-generated from /mnt/user-data/uploads/master.png
#ifndef BG_MASTER_H
#define BG_MASTER_H

#include <gba.h>

#define BG_MASTER_WIDTH 240
#define BG_MASTER_HEIGHT 160

extern const u16 bg_master[38400];  // 240x160 pixels

#endif // BG_MASTER_H
