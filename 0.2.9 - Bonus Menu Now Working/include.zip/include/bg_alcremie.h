#ifndef BG_ALCREMIE_H
#define BG_ALCREMIE_H

#include <gba_types.h>

extern const u16 bg_alcremie_bitmap[38400];

#endif
