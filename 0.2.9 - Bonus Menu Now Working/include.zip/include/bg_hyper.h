// Auto-generated from /mnt/user-data/uploads/hyper.png
#ifndef BG_HYPER_H
#define BG_HYPER_H

#include <gba.h>

#define BG_HYPER_WIDTH 240
#define BG_HYPER_HEIGHT 160

extern const u16 bg_hyper[38400];  // 240x160 pixels

#endif // BG_HYPER_H
